function AT = deMeanOperator(p_sz)

AT = eye((p_sz)^2)-1/(p_sz)^2*ones((p_sz)^2);

end