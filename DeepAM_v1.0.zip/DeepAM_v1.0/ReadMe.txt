This folder contains the MATLAB implementation for the paper "Learning Deep Analysis Dictionaries for Image
Super-Resolution".

Module Leader: Prof. Pier Luigi Dragotti 
PhD Student: Dr. Jun-Jie Huang (j.huang15@imperial.ac.uk)

If you have any queries, please feel free to contact.

########################################################################
Version 1.0
- 2021-07-01 First release. Detailed comments have been added for easier usage.


########################################################################
How to use the code?
1. use trainDeepAM.m to perform training.

2. use testDeepAM.m to perform testing on Set5 or Set14. 

In the folder models, there are 3 learned models using trainDeepAM.m corresponding to learning without noise and with noise level 0.1.


########################################################################
If you find the code useful, please cite our paper:

J.J. Huang and P.L. Dragotti, Learning Deep Analysis Dictionaries for Image Super-Resolution, IEEE Transactions on Signal Processing, vol. 68, pages: 6633 - 6648, 2020.

BibTeX:

@ARTICLE{Huang2020DeepAM,
	author={Huang, Jun-Jie and Dragotti, Pier Luigi},
  	journal={IEEE Transactions on Signal Processing}, 
  	title={Learning Deep Analysis Dictionaries for Image Super-Resolution}, 
  	year={2020},
  	volume={68},
  	number={},
  	pages={6633-6648},
  	doi={10.1109/TSP.2020.3036902}
}